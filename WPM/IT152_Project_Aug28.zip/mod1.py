def gfg():
    print("Welcome to GFG")
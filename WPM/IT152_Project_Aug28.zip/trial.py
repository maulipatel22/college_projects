import pygame


pygame.init()
WIDTH = 800
HEIGHT = 600
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
ORANGE = (255, 127, 0)
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('KEYBOARD NINJA')
SCREEN.fill(BLACK)

is_running = True
while is_running:
    pygame.display.flip()
    GAME_CONTENT = pygame.font.SysFont(None, 50)
    GAME_CONTENT_img = GAME_CONTENT.render('GAME CONTENTS', True, ORANGE)
    SCREEN.blit(GAME_CONTENT_img, (50, 100))
    WORDPERMIN = pygame.font.SysFont(None, 35)
    WORDPERMIN_img = WORDPERMIN.render('WORDPERMIN', True, ORANGE)
    SCREEN.blit(WORDPERMIN_img, (550, 200))

pygame.quit()